import 'package:flutter/material.dart';
import 'package:realstate/pages/login.page.dart';

class OnboardingPage1 extends StatelessWidget {
  const OnboardingPage1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF6F7FB),
      body: SafeArea(
        child: Column(
          children: [

            const SizedBox(height: 10),

            /// ==== TOP ILLUSTRATION ====
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Image.asset(
                "assets/Frame 1171275471.png", // replace with your exact illustration
                height: 320,
                fit: BoxFit.contain,
              ),
            ),

            const SizedBox(height: 30),

            /// ==== TITLE ====
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 30),
              child: Text(
                "Find Your Perfect Home\nEasily",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  color: Color(0xffE86A34),
                  height: 1.3,
                ),
              ),
            ),

            const SizedBox(height: 18),

            /// ==== DESCRIPTION ====
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 28),
              child: Text(
                "Discover verified properties, trusted agents, "
                "and smooth buying–selling experiences — all in one place. "
                "Your dream home is now just a tap away.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15.5,
                  height: 1.55,
                  color: Color(0xff7B7B7B),
                ),
              ),
            ),

            const Spacer(),

            /// ==== PAGE INDICATOR DOTS ====
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                dot(true),
                const SizedBox(width: 10),
                dot(false),
                const SizedBox(width: 10),
                dot(false),
              ],
            ),

            const SizedBox(height: 40),

            /// ==== NEXT BUTTON + SKIP ====
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  /// Skip Button
                  const Text(
                    "Skip",
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xffE86A34),
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  /// Round next arrow button
                  GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Container(
                      height: 65,
                      width: 65,
                      decoration: const BoxDecoration(
                        color: Color(0xffE86A34),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),
          ],
        ),
      ),
    );
  }

  /// Page indicator dot
  Widget dot(bool active) {
    return Container(
      width: 14,
      height: 14,
      decoration: BoxDecoration(
        color: active ? const Color(0xffE86A34) : const Color(0xffF2C3A5),
        shape: BoxShape.circle,
      ),
    );
  }
}
