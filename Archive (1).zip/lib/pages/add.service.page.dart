
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AddServicePage extends StatelessWidget {
  const AddServicePage({super.key});

  final List<Map<String, String>> categories = const [
    {'label': 'ELECTRICIAN', 'url': 'https://media.angi.com/s3fs-public/stacey-shurr-bathroom-remodel.jpg?impolicy=leadImage'}, // Replace with actual
    {'label': 'CARPENTER', 'url': 'https://s3-media0.fl.yelpcdn.com/bphoto/y2N9GweV0RhaXx9dYbXHTA/l.jpg'},
    {'label': 'PAINTER', 'url': 'https://www.shutterstock.com/image-vector/worker-repair-service-plumber-handyman-260nw-2234725577.jpg'},
    {'label': 'PLUMBER', 'url': 'https://cdn.prod.website-files.com/5e593fb060cf877cf875dd1f/679085ac60c170e5ebba4b34_recBrwtY2JtNJji6k_image_1.webp'},
    {'label': 'CLEANING', 'url': 'https://www.shutterstock.com/shutterstock/videos/3684051321/thumb/4.jpg?ip=x480'},
    {'label': 'INTERIOR', 'url': 'https://s3-media0.fl.yelpcdn.com/bphoto/tuGs0mGEDRuE8omqeINuKQ/l.jpg'},
    {'label': 'RENOVATION', 'url': 'https://cdn.prod.website-files.com/5e593fb060cf877cf875dd1f/677c007c62c5db1e8a3b1317_handyman-webflow-template.png'},
    {'label': 'PEST CONTROL', 'url': 'https://media.angi.com/s3fs-public/vintage-bathroom-remodel-house-call.jpg'},
  ];

  final List<Map<String, String>> services = const [
    {'icon': 'Toilet Repair', 'title': 'Toilet Repair', 'desc': 'Fast, reliable toilet fixes that restore comfort and functionality.'},
    {'icon': 'Faucet Installation', 'title': 'Faucet Installation', 'desc': 'Expert faucet installation and repair for every style.'},
    {'icon': 'Sewer Inspection', 'title': 'Sewer Inspection', 'desc': 'Advanced camera inspections to prevent damage.'},
    {'icon': 'Sewer Inspection', 'title': 'Sewer Inspection', 'desc': 'Advanced camera inspections to prevent damage.'}, // Duplicate in screenshot, adjust if needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.black), onPressed: () {}),
        title: const Text('HOME SERVICE', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
        actions: [
          TextButton(onPressed: () {}, child: const Text('+ ADD HOME SERVICE', style: TextStyle(color: Colors.orange))),
        ],
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Categories Grid
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                childAspectRatio: 1,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(categories[index]['url']!, width: 60, height: 60, fit: BoxFit.cover),
                    ),
                    const SizedBox(height: 8),
                    Text(categories[index]['label']!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                  ],
                );
              },
            ),

            // We Provide Quality Services
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('We Provide Quality Services', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),

            // Services Grid
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              childAspectRatio: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              children: [
                ServiceCard(title: 'Toilet Repair', desc: 'Fast, reliable toilet fixes that restore comfort and functionality.', imageUrl: 'https://media.gettyimages.com/id/2192255408/vector/plumbing-line-icon-set-group-of-object-pipe-bathtub-boiler-faucet-repair.jpg?s=612x612&w=gi&k=20&c=IgKlfAmPPCWSHJy7L_KlG4bjVyB_If33cqFTI8X51Ng='),
                ServiceCard(title: 'Faucet Installation', desc: 'Expert faucet installation and repair for every style.', imageUrl: 'https://media.istockphoto.com/id/1140334314/vector/plumber-master-with-wrench-fixing-kitchen-faucet.jpg?s=612x612&w=0&k=20&c=5XTiydIT32QfXU-x8WVM6rSeWpy6TopGU66RNfPunw4='),
                ServiceCard(title: 'Sewer Inspection', desc: 'Advanced camera inspections to prevent damage.', imageUrl: 'https://media.istockphoto.com/id/2194903933/vector/plumbers-and-plumbing-thin-line-icons-editable-stroke-icons-include-plumbing-pipes-leaky.jpg?s=612x612&w=0&k=20&c=V2EAWro2g_Xk72Bl9c0LJ78ylpTxzZaZcyct56nqwCc='),
                ServiceCard(title: 'Sewer Inspection', desc: 'Advanced camera inspections to prevent damage.', imageUrl: 'https://media.istockphoto.com/id/1363041172/vector/water-tank-pipe-pipeline-and-sewerage-cleaning-service-by-cleaner.jpg?s=612x612&w=0&k=20&c=OPh5837hpAV13c5fsr3daJrrzFK1E4HjSEhiDdgZwN0='),
              ],
            ),

            // Why We Are / Easy Solutions
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text('Why We Are', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Text('Easy Solutions For Plumbing and Home Repair Needs', style: TextStyle(fontSize: 16)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: const [
                      Chip(label: Text('Tech Expertise')),
                      Chip(label: Text('Advanced Tools')),
                      Chip(label: Text('Smart Solutions')),
                    ],
                  ),
                  ElevatedButton(onPressed: () {}, style: ElevatedButton.styleFrom(backgroundColor: Colors.orange), child: const Text('Hire Experts')),
                ],
              ),
            ),

            // Plumber Image
            Image.network('https://as1.ftcdn.net/jpg/05/94/89/64/1000_F_594896473_PmXb07nS8Odld7O3op4E5Vi2USzODYYc.jpg', fit: BoxFit.cover, width: double.infinity),

            // Affordable Pricing
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: const [
                  Icon(Icons.price_check, size: 40, color: Colors.orange),
                  Text('Affordable Pricing', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text('Quality service doesn\'t have to be costly. We offer transparent, fair pricing on every job.'),
                ],
              ),
            ),

            // Featured Projects
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Featured Projects', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  TextButton(onPressed: () {}, child: const Text('See Full Gallery >', style: TextStyle(color: Colors.orange))),
                ],
              ),
            ),
            SizedBox(
              height: 200,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  FeaturedProject(imageUrl: 'https://images.finehomebuilding.com/app/uploads/2016/04/09114955/021181bs116-01_xlg.jpg', title: 'Drain Overhaul', subtitle: 'Complete drain system upgrade'),
                  FeaturedProject(imageUrl: 'https://www.thespruce.com/thmb/e-MxaOBy4AKp4JW1XFZGbrkDaIw=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/how-to-install-a-sink-drain-2718789_hero_5078-64538f6f90d545c7af0728e4bf8f894e.jpg', title: 'Sink Installation', subtitle: 'New kitchen sink setup'),
                  FeaturedProject(imageUrl: 'https://gharpedia.com/_next/image/?url=https%3A%2F%2Fcloudfrontgharpediabucket.gharpedia.com%2Fuploads%2F2021%2F12%2FBest-Way-to-Install-a-Bathroom-Sink-Drain-01-0504130013.jpg&w=3840&q=75', title: 'Drain Overhaul', subtitle: 'Complete drain system upgrade'),
                ],
              ),
            ),

            // Latest Insights
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Our Latest Insights', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Image.network('https://wg.scene7.com/is/image/wrenchgroup/insulate-pipes-info-ps22wi001wg?&wid=362', width: 100, height: 100, fit: BoxFit.cover),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text('How to Protect Your Pipes During Cold Weather', style: TextStyle(fontWeight: FontWeight.bold)),
                        Text('Read More >', style: TextStyle(color: Colors.orange)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class ServiceCard extends StatelessWidget {
  final String title;
  final String desc;
  final String imageUrl;

  const ServiceCard({super.key, required this.title, required this.desc, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Row(
        children: [
          Image.network(imageUrl, width: 80, height: 80, fit: BoxFit.cover),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(desc, style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FeaturedProject extends StatelessWidget {
  final String imageUrl;
  final String title;
  final String subtitle;

  const FeaturedProject({super.key, required this.imageUrl, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      margin: const EdgeInsets.only(right: 16),
      child: Stack(
        children: [
          Image.network(imageUrl, fit: BoxFit.cover, width: double.infinity, height: double.infinity),
          Container(color: Colors.black54),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ElevatedButton(onPressed: () {}, style: ElevatedButton.styleFrom(backgroundColor: Colors.orange), child: Text(title)),
                Text(subtitle, style: const TextStyle(color: Colors.white)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}