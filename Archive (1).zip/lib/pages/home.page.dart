import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:realstate/pages/propertyCat.page.dart';

class RealEstateHomePage extends StatelessWidget {
  const RealEstateHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F7FA),
      bottomNavigationBar: _bottomNav(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12),

                /// --------------- TOP BAR ----------------
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Let’s Find your\nFavorite Home",
                      style: GoogleFonts.poppins(
                        fontSize: 26,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xff0A1F44),
                      ),
                    ),
                    const CircleAvatar(
                      radius: 25,
                      backgroundImage: NetworkImage(
                        "https://i.ibb.co/9hPxQ2M/girl.jpg",
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 25),

                /// --------------- SEARCH + FILTER ----------------
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 55,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            )
                          ],
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        child: Row(
                          children: [
                            Icon(Icons.search,
                                color: Colors.grey.shade400, size: 26),
                            const SizedBox(width: 10),
                            Text(
                              "Search",
                              style: GoogleFonts.poppins(
                                fontSize: 15,
                                color: Colors.grey.shade500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Container(
                      height: 55,
                      width: 55,
                      decoration: BoxDecoration(
                        color: const Color(0xffFF784B),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Icon(Icons.tune, color: Colors.white, size: 28),
                    ),
                  ],
                ),

                const SizedBox(height: 25),

                /// ----------------- BANNER IMAGE -----------------
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    children: [
                      Image.network(
                        "https://i.ibb.co/fNw50fh/jaipur.jpg",
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                      Positioned(
                        left: 20,
                        bottom: 20,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "FIND POPULAR PROPERTIES",
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Text(
                              "IN JAIPUR",
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                /// ----------------- TAB BAR -----------------
                Row(
                  children: [
                    _tabItem("Buy Rent Property", true),
                    _tabItem("All Services", false),
                    _tabItem("Loan & More", false),
                    Icon(Icons.chevron_right,
                        color: Colors.grey.shade600, size: 22),
                  ],
                ),

                const SizedBox(height: 15),

                /// ----------------- GRID ITEMS -----------------
                _gridItem("HOUSE", "https://i.ibb.co/ZVtn8wV/house.jpg",),
                _gridItem("FLATS", "https://i.ibb.co/Lkh1pTq/flats.jpg"),

                _gridItem("DUPLEX", "https://i.ibb.co/4ZqVwYg/duplex.jpg"),
                _gridItem("PLOTS", "https://i.ibb.co/FX3WPCg/plots.jpg"),

                _gridItem("COMMERCIAL PROPERTIES",
                    "https://i.ibb.co/ZxgZ6qg/commercial.jpg"),
                _gridItem("HOTELS", "https://i.ibb.co/GxFZWtn/hotels.jpg"),

                _gridItem("CONDOS", "https://i.ibb.co/Rz5GhnG/condo.jpg"),
                _gridItem("STUDIOS", "https://i.ibb.co/VQd0m6Y/studios.jpg"),

                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: _whatsappButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniEndFloat,
    );
  }

  /// ----------------- GRID CARD -----------------
  Widget _gridItem(String title, String image) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Expanded(child: _gridCard(title, image)),
          const SizedBox(width: 12),
          Expanded(child: _gridCard(title, image)),
        ],
      ),
    );
  }

  Widget _gridCard(String title, String image) {
    return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          children: [
            Image.network(
              image,
              height: 140,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            Container(
              height: 140,
              alignment: Alignment.center,
              color: Colors.black.withOpacity(0.25),
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      );
  }

  /// ----------------- TAB TEXT -----------------
  Widget _tabItem(String text, bool active) {
    return Padding(
      padding: const EdgeInsets.only(right: 18),
      child: Column(
        children: [
          Text(
            text,
            style: GoogleFonts.poppins(
              fontSize: 15,
              fontWeight: active ? FontWeight.w600 : FontWeight.w400,
              color: active ? const Color(0xffFF784B) : Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 4),
          if (active)
            Container(
              height: 3,
              width: 50,
              color: const Color(0xffFF784B),
            )
        ],
      ),
    );
  }

  /// ----------------- WHATSAPP BUTTON -----------------
  Widget _whatsappButton() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xff42C65D),
        borderRadius: BorderRadius.circular(40),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
           Icon(Icons.whatshot_sharp, color: Colors.white),
          const SizedBox(width: 8),
          Text(
            "Let’s Connect",
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          )
        ],
      ),
    );
  }

  /// ----------------- BOTTOM NAV -----------------
  Widget _bottomNav() {
    return BottomNavigationBar(
      backgroundColor: Colors.white,
      selectedItemColor: const Color(0xffFF784B),
      unselectedItemColor: Colors.grey.shade500,
      type: BottomNavigationBarType.fixed,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: ""),
        BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), label: ""),
        BottomNavigationBarItem(icon: Icon(Icons.add_circle_outline), label: ""),
        BottomNavigationBarItem(
            icon: Icon(Icons.account_circle_outlined), label: ""),
      ],
    );
  }
}
