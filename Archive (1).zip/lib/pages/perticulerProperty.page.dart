import 'package:flutter/material.dart';



class PerticulerPropertyPage extends StatelessWidget {
  const PerticulerPropertyPage({super.key});

  // Category data
  final List<Map<String, String>> categories = const [
    {'label': 'ELECTRICIAN', 'url': 'https://img.freepik.com/free-photo/electrician-working-house-repair-installation_1303-25038.jpg'},
    {'label': 'CARPENTER', 'url': 'https://img.freepik.com/free-photo/carpenter-working-wooden-furniture_1150-100.jpg'},
    {'label': 'PAINTER', 'url': 'https://img.freepik.com/free-photo/painter-painting-wall_23-2149371488.jpg'},
    {'label': 'PLUMBER', 'url': 'https://img.freepik.com/free-photo/plumber-fixing-pipe_23-2149371490.jpg'},
    {'label': 'INTERIOR CLEANING', 'url': 'https://img.freepik.com/free-photo/cleaning-service-concept-with-supplies_23-2149371500.jpg'},
    {'label': 'DRILL & HANG', 'url': 'https://img.freepik.com/free-photo/man-hanging-picture-wall_23-2149371510.jpg'},
    {'label': 'SECURITY GUARD', 'url': 'https://img.freepik.com/free-photo/security-guard-standing-front-building_23-2149371520.jpg'},
    {'label': 'FABRICATION', 'url': 'https://img.freepik.com/free-photo/welder-working-metal_23-2149371530.jpg'},
    {'label': 'FABRICATION', 'url': 'https://img.freepik.com/free-photo/construction-worker-site_23-2149371540.jpg'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.black), onPressed: () {}),
        title: const Text('HOME SERVICE', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text('+ ADD HOME SERVICE', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Categories Grid (3x3 + 1 extra)
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 1,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              itemCount: categories.length,
              itemBuilder: (context, i) {
                return Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        categories[i]['url']!,
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: Colors.grey[300], child: const Icon(Icons.image)),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(categories[i]['label']!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                  ],
                );
              },
            ),

            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text('What We Offer', style: TextStyle(fontSize: 16, color: Colors.grey)),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('We Provide Quality Services', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),

            // Quality Services Grid
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 2.2,
              children: [
                _serviceCard('Toilet Repair', 'Fast, reliable toilet fixes that restore comfort and functionality.', Icons.plumbing),
                _serviceCard('Faucet Installation', 'Expert faucet installation and repair for every style.', Icons.build),
                _serviceCard('Sewer Inspection', 'Advanced camera inspections to prevent damage.', Icons.camera_alt),
                _serviceCard('Sewer Inspection', 'Advanced camera inspections to prevent damage.', Icons.camera_alt),
              ],
            ),

            const SizedBox(height: 24),

            // Why We Are
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('Why We Are', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text('Easy Solutions for Plumbing and Home Repair Needs', style: TextStyle(fontSize: 16)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Chip(label: const Text('Tech Expertise')),
                  Chip(label: const Text('Advanced Tools')),
                  Chip(label: const Text('Smart Solutions')),
                ],
              ),
            ),
            const SizedBox(height: 8),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('Our team leverages technical expertise to deliver precise, reliable plumbing and handyman solutions for every home.'),
            ),
            const SizedBox(height: 16),
            Center(
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16)),
                child: const Text('Hire Experts', style: TextStyle(fontSize: 16)),
              ),
            ),

            const SizedBox(height: 24),

            // Plumber Image
            Image.network(
              'https://img.freepik.com/free-photo/plumber-repairing-pipe_23-2149371550.jpg',
              width: double.infinity,
              height: 250,
              fit: BoxFit.cover,
            ),

            const SizedBox(height: 24),

            // Affordable Pricing
            const Center(child: Icon(Icons.attach_money, size: 50, color: Colors.orange)),
            const Center(child: Text('Affordable Pricing', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Quality service doesn\'t have to be costly; offer transparent, fair pricing on every job.', textAlign: TextAlign.center),
            ),

            const SizedBox(height: 16),

            // Featured Projects
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Featured Projects', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  TextButton(onPressed: () {}, child: const Text('See Full Gallery >', style: TextStyle(color: Colors.orange))),
                ],
              ),
            ),
            SizedBox(
              height: 220,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _featuredProject('https://img.freepik.com/free-photo/sink-drain-repair_23-2149371560.jpg', 'Drain Overhaul', 'Complete drain system upgrade'),
                  _featuredProject('https://img.freepik.com/free-photo/plumber-working-sink_23-2149371570.jpg', 'Drain Overhaul', 'Complete drain system upgrade'),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Latest Insights
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('Our Latest Insights', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.network(
                      'https://img.freepik.com/free-photo/plumber-working-kitchen_23-2149371580.jpg',
                      width: 120,
                      height: 120,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('How to Protect Your Pipes During Cold Weather', style: TextStyle(fontWeight: FontWeight.bold)),
                        SizedBox(height: 8),
                        Text('Read More >', style: TextStyle(color: Colors.orange)),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _serviceCard(String title, String desc, IconData icon) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, size: 40, color: Colors.orange),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(desc, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _featuredProject(String imgUrl, String title, String subtitle) {
    return Container(
      width: 280,
      margin: const EdgeInsets.only(right: 16),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(imgUrl, fit: BoxFit.cover, width: double.infinity, height: double.infinity),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: const LinearGradient(colors: [Colors.transparent, Colors.black54], begin: Alignment.topCenter, end: Alignment.bottomCenter),
            ),
          ),
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                  child: Text(title),
                ),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.white)),
              ],
            ),
          ),
          const Positioned(
            top: 16,
            right: 16,
            child: CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.arrow_forward, color: Colors.orange)),
          ),
        ],
      ),
    );
  }
}